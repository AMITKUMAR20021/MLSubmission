# Movie Recommendation GUI

This project implements a simple graphical user interface (GUI) for a movie recommendation system using Python and Tkinter.

## Requirements
- Python 3.x
- Pandas library (install using `pip install pandas`)
- NumPy library (install using `pip install numpy`)
- SciPy library (install using `pip install scipy`)
- Scikit-learn library (install using `pip install scikit-learn`)
- Matplotlib library (install using `pip install matplotlib`)
- Tkinter library (usually included with Python)

## Setup
1. Download the source code files.
2. Make sure you have Python installed on your system.
3. Install the required libraries by running the following commands in your terminal:

```bash
pip install pandas numpy scipy scikit-learn matplotlib
```

## Usage
1. Ensure that the following files are present in the project directory:
- `movie_recommendation_gui.py`: Python script containing the GUI implementation.
- `User-Item Matrix using K-nearest neighbors.py`: Python script containing the movie recommendation function.
- `movies.csv`: Dataset containing movie information.
- `ratings.csv`: Dataset containing movie ratings provided by users.
2. Run the `movie_recommendation_gui.py` file using Python.
3. Enter the name of a movie in the input field.
4. Click the "Recommend" button to see movie recommendations based on the entered movie.
5. The recommendations will be displayed in the text box below the input field.

## Files
- `movie_recommendation_gui.py`: Python script containing the GUI implementation.
- `User-Item Matrix using K-nearest neighbors.py`: Python script containing the movie recommendation function.
- `movies.csv`: Dataset containing movie information.
- `ratings.csv`: Dataset containing movie ratings provided by users.

## Notes
- The recommendation function is implemented in the `User-Item Matrix using K-nearest neighbors.py` file. Make sure to update this file if you want to modify the recommendation algorithm or add new features.
- The GUI is implemented using Tkinter. You can customize the GUI layout and appearance by modifying the code in `movie_recommendation_gui.py`.
- Ensure that all dataset files (`movies.csv`, `ratings.csv`) are present in the same directory as the Python scripts.

