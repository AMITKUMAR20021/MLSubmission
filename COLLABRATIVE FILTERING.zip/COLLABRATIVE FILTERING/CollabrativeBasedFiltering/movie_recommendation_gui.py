import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
import pandas as pd

from user_item_matrix_using_k_nearest_neighbors import get_movie_recommendation

# Import your recommendation function and necessary data here
# from your_module import get_movie_recommendation, movies, final_dataset, knn, csr_data

# Define your recommendation function
# def get_movie_recommendation(movie_name):
    # Your recommendation function code here

# Create the main application window
root = tk.Tk()
root.title("Movie Recommendation")

# Define function to handle button click event
def recommend_movie():
    movie_name = entry_movie.get()
    if movie_name:
        try:
            recommendation_df = get_movie_recommendation(movie_name)
            # Clear previous recommendation text
            text_recommendation.delete(1.0, tk.END)
            # Display recommendation in text box
            if isinstance(recommendation_df, pd.DataFrame):
                text_recommendation.insert(tk.END, recommendation_df.to_string())
            else:
                text_recommendation.insert(tk.END, recommendation_df)
        except Exception as e:
            messagebox.showerror("Error", str(e))
    else:
        messagebox.showerror("Error", "Please enter a movie name.")

# Create and place widgets
label_movie = ttk.Label(root, text="Enter movie name:")
label_movie.grid(row=0, column=0, padx=5, pady=5)

entry_movie = ttk.Entry(root)
entry_movie.grid(row=0, column=1, padx=5, pady=5)

button_recommend = ttk.Button(root, text="Recommend", command=recommend_movie)
button_recommend.grid(row=0, column=2, padx=5, pady=5)

text_recommendation = tk.Text(root, height=10, width=50)
text_recommendation.grid(row=1, columnspan=3, padx=5, pady=5)

# Run the application
root.mainloop()